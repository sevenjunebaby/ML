from flask import Flask, request, jsonify, render_template
import cv2
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.preprocessing import LabelEncoder
import os
import joblib
import base64

app = Flask(__name__, static_folder='static')

# Load the trained model
pipeline_path = os.path.join(app.static_folder, 'model.pkl')
pipeline = joblib.load(pipeline_path)

# Load label encoder
label_encoder_path = os.path.join(app.static_folder, 'label_encoder_classes.npy')
label_encoder = LabelEncoder()
label_encoder.classes_ = np.load(label_encoder_path)

# Function to extract features from images
'''def extract_features(image, target_size=(100, 100)):
    img = cv2.resize(image, target_size)  # Resize the image to a fixed size
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)
    return edges.flatten(), edges  # Return both flattened features and edges image'''
def extract_features(image):
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Detect edges with Canny
    edges = cv2.Canny(blurred, 50, 150)

    return edges.flatten(), edges  # Keep original size

# Function to preprocess image and make predictions
def predict_shape(image):
    features, edges = extract_features(image)
    prediction = pipeline.predict([features])
    predicted_shape = label_encoder.inverse_transform(prediction)[0]
    return predicted_shape, edges

@app.route("/")
def root():
    return render_template("index.html")

# Route to upload an image and get predictions
@app.route("/predict", methods=["POST"])
def predict():
    if request.method == "POST":
        # Check if an image file is uploaded
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"})
        
        file = request.files["file"]
        
        # Check if the file is empty
        if file.filename == "":
            return jsonify({"error": "No file selected"})
        
        # Check if the file is an allowed format
        if file:
            # Read the image file
            image = cv2.imdecode(np.fromstring(file.read(), np.uint8), cv2.IMREAD_COLOR)
            # Get predictions and edges
            predicted_shape, edges = predict_shape(image)
            
            # Encode the edges image to base64
            _, buffer = cv2.imencode('.png', edges)
            edges_base64 = base64.b64encode(buffer).decode('utf-8')
            
            return jsonify({"predicted_shape": predicted_shape, "edges_image": edges_base64})

if __name__ == "__main__":
    app.run()
